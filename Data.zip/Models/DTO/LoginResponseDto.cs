﻿using WebAPIDemoNew.Models.DTO;

namespace WebAPIDemoNew.Models
{
    public class LoginResponseDto
    {
        public string? Token { get; set; }
        public UserDto? userDto { get; set; } 
    }
}
