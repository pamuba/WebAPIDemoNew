﻿using System.ComponentModel.DataAnnotations;

namespace WebAPIDemoNew.Models.DTO
{
	public class CreateVillaDTO
	{
		[Required]
		[MaxLength(30)]
		public required string Name { get; set; }
		public string? Details { get; set; }
		public double Rate { get; set; }
		public int Sqft { get; set; }
		public int Occupancy { get; set; }
		public string? ImageUrl { get; set; }
	}
}
